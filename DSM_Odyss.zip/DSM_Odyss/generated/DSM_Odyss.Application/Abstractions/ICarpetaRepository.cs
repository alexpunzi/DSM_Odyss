﻿using DSM_Odyss.Domain.Entities;

namespace DSM_Odyss.Application.Abstractions;

public interface ICarpetaRepository : IRepository<Carpeta>
{
    Task<IReadOnlyList<Carpeta>> ConMultimediaAsync();
}
