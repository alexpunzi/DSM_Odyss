﻿using DSM_Odyss.Application.Abstractions;
using DSM_Odyss.Application.Exceptions;
using DSM_Odyss.Domain.Entities;
using DSM_Odyss.Domain.Enums;

        /*PROTECTED REGION ID(usingDSM_Odyss.Application.Services_Multimedia_moverACarpeta) ENABLED START*/
        // references to other libraries
        /*PROTECTED REGION END*/

namespace DSM_Odyss.Application.Services;

public sealed partial class MultimediaService
{
    public async Task MoverACarpetaAsync(int p_oid, int p_nuevaCarpeta_oid)
    {
        /*PROTECTED REGION ID(DSM_Odyss.Application.Services_Multimedia_moverACarpeta) ENABLED START*/
        await MoverDeCarpetaAsync(p_oid, p_nuevaCarpeta_oid);
        /*PROTECTED REGION END*/
    }
}
