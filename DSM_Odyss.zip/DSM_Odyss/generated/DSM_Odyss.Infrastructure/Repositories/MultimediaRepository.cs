﻿using Microsoft.Extensions.Logging;
using NHibernate;
using NHibernate.Linq;
using DSM_Odyss.Application.Abstractions;
using DSM_Odyss.Domain.Entities;
using DSM_Odyss.Domain.Enums;
using DSM_Odyss.Domain.ValueObjects;
using DSM_Odyss.Infrastructure.Exceptions;

namespace DSM_Odyss.Infrastructure.Repositories;

public sealed class MultimediaRepository : RepositoryBase<Multimedia>, IMultimediaRepository
{
    public MultimediaRepository(ILogger<MultimediaRepository>? logger = null)
        : base(logger)
    {
    }

    public MultimediaRepository(ISession session, ILogger<MultimediaRepository>? logger = null)
        : base(session, logger)
    {
    }

    public MultimediaRepository(ISessionFactory sessionFactory, ILogger<MultimediaRepository>? logger = null)
        : base(sessionFactory, logger)
    {
    }

    public async Task<IReadOnlyList<Multimedia>> ReadAllAsync()
    {
        try
        {
            using var context = OpenSession();
            return await context.Session.Query<Multimedia>().ToListAsync();
        }
        catch (Exception ex)
        {
            Logger?.LogError(ex, "Error reading all {Entity} entities.", EntityName);
            throw new DataException($"Error reading all {EntityName} entities.", ex);
        }
    }

    public async Task<Multimedia?> ReadAsync(object id)
    {
        try
        {
            using var context = OpenSession();
            return await context.Session.GetAsync<Multimedia>(id);
        }
        catch (Exception ex)
        {
            Logger?.LogError(ex, "Error reading {Entity} entity with id {EntityId}.", EntityName, id);
            throw new DataException($"Error reading {EntityName} entity.", ex);
        }
    }

    public async Task SaveAsync(Multimedia entity)
    {
        await ExecuteRepositoryOperationInTransactionAsync(
            "Save",
            session => session.SaveOrUpdateAsync(entity),
            $"Error saving {EntityName} entity.");
    }

    public async Task DeleteAsync(Multimedia entity)
    {
        await ExecuteRepositoryOperationInTransactionAsync(
            "Delete",
            session => session.DeleteAsync(entity),
            $"Error deleting {EntityName} entity.");
    }

    public async Task<IReadOnlyList<Multimedia>> DelTipoAsync(TipoMultimedia p_tipo)
    {
        try
        {
            using var context = OpenSession();
            return await context.Session.Query<Multimedia>()
                .Where(entity => entity.Tipo == p_tipo)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            Logger?.LogError(ex, "Error executing ReadFilter Multimedia.delTipo.");
            throw new DataException("Error executing ReadFilter Multimedia.delTipo.", ex);
        }
    }
}