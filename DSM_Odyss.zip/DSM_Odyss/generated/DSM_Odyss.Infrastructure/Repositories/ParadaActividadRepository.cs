﻿using Microsoft.Extensions.Logging;
using NHibernate;
using NHibernate.Linq;
using DSM_Odyss.Application.Abstractions;
using DSM_Odyss.Domain.Entities;
using DSM_Odyss.Domain.Enums;
using DSM_Odyss.Domain.ValueObjects;
using DSM_Odyss.Infrastructure.Exceptions;

namespace DSM_Odyss.Infrastructure.Repositories;

public sealed class ParadaActividadRepository : RepositoryBase<ParadaActividad>, IParadaActividadRepository
{
    public ParadaActividadRepository(ILogger<ParadaActividadRepository>? logger = null)
        : base(logger)
    {
    }

    public ParadaActividadRepository(ISession session, ILogger<ParadaActividadRepository>? logger = null)
        : base(session, logger)
    {
    }

    public ParadaActividadRepository(ISessionFactory sessionFactory, ILogger<ParadaActividadRepository>? logger = null)
        : base(sessionFactory, logger)
    {
    }

    public async Task<IReadOnlyList<ParadaActividad>> ReadAllAsync()
    {
        try
        {
            using var context = OpenSession();
            return await context.Session.Query<ParadaActividad>().ToListAsync();
        }
        catch (Exception ex)
        {
            Logger?.LogError(ex, "Error reading all {Entity} entities.", EntityName);
            throw new DataException($"Error reading all {EntityName} entities.", ex);
        }
    }

    public async Task<ParadaActividad?> ReadAsync(object id)
    {
        try
        {
            using var context = OpenSession();
            return await context.Session.GetAsync<ParadaActividad>(id);
        }
        catch (Exception ex)
        {
            Logger?.LogError(ex, "Error reading {Entity} entity with id {EntityId}.", EntityName, id);
            throw new DataException($"Error reading {EntityName} entity.", ex);
        }
    }

    public async Task SaveAsync(ParadaActividad entity)
    {
        await ExecuteRepositoryOperationInTransactionAsync(
            "Save",
            session => session.SaveOrUpdateAsync(entity),
            $"Error saving {EntityName} entity.");
    }

    public async Task DeleteAsync(ParadaActividad entity)
    {
        await ExecuteRepositoryOperationInTransactionAsync(
            "Delete",
            session => session.DeleteAsync(entity),
            $"Error deleting {EntityName} entity.");
    }

    public async Task<IReadOnlyList<ParadaActividad>> PendientesAsync()
    {
        try
        {
            using var context = OpenSession();
            return await context.Session.Query<ParadaActividad>()
                .Where(entity => !entity.Completada)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            Logger?.LogError(ex, "Error executing ReadFilter ParadaActividad.pendientes.");
            throw new DataException("Error executing ReadFilter ParadaActividad.pendientes.", ex);
        }
    }
}