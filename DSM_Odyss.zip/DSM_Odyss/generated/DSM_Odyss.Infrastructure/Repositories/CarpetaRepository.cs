﻿using Microsoft.Extensions.Logging;
using NHibernate;
using NHibernate.Linq;
using DSM_Odyss.Application.Abstractions;
using DSM_Odyss.Domain.Entities;
using DSM_Odyss.Domain.Enums;
using DSM_Odyss.Domain.ValueObjects;
using DSM_Odyss.Infrastructure.Exceptions;

namespace DSM_Odyss.Infrastructure.Repositories;

public sealed class CarpetaRepository : RepositoryBase<Carpeta>, ICarpetaRepository
{
    public CarpetaRepository(ILogger<CarpetaRepository>? logger = null)
        : base(logger)
    {
    }

    public CarpetaRepository(ISession session, ILogger<CarpetaRepository>? logger = null)
        : base(session, logger)
    {
    }

    public CarpetaRepository(ISessionFactory sessionFactory, ILogger<CarpetaRepository>? logger = null)
        : base(sessionFactory, logger)
    {
    }

    public async Task<IReadOnlyList<Carpeta>> ReadAllAsync()
    {
        try
        {
            using var context = OpenSession();
            return await context.Session.Query<Carpeta>().ToListAsync();
        }
        catch (Exception ex)
        {
            Logger?.LogError(ex, "Error reading all {Entity} entities.", EntityName);
            throw new DataException($"Error reading all {EntityName} entities.", ex);
        }
    }

    public async Task<Carpeta?> ReadAsync(object id)
    {
        try
        {
            using var context = OpenSession();
            return await context.Session.GetAsync<Carpeta>(id);
        }
        catch (Exception ex)
        {
            Logger?.LogError(ex, "Error reading {Entity} entity with id {EntityId}.", EntityName, id);
            throw new DataException($"Error reading {EntityName} entity.", ex);
        }
    }

    public async Task SaveAsync(Carpeta entity)
    {
        await ExecuteRepositoryOperationInTransactionAsync(
            "Save",
            session => session.SaveOrUpdateAsync(entity),
            $"Error saving {EntityName} entity.");
    }

    public async Task DeleteAsync(Carpeta entity)
    {
        await ExecuteRepositoryOperationInTransactionAsync(
            "Delete",
            session => session.DeleteAsync(entity),
            $"Error deleting {EntityName} entity.");
    }

    public async Task<IReadOnlyList<Carpeta>> ConMultimediaAsync()
    {
        try
        {
            using var context = OpenSession();
            return await context.Session.Query<Carpeta>()
                .Where(entity => entity.Multimedia.Any())
                .ToListAsync();
        }
        catch (Exception ex)
        {
            Logger?.LogError(ex, "Error executing ReadFilter Carpeta.conMultimedia.");
            throw new DataException("Error executing ReadFilter Carpeta.conMultimedia.", ex);
        }
    }
}