﻿using Microsoft.Extensions.Logging;
using NHibernate;
using NHibernate.Linq;
using DSM_Odyss.Application.Abstractions;
using DSM_Odyss.Domain.Entities;
using DSM_Odyss.Domain.Enums;
using DSM_Odyss.Domain.ValueObjects;
using DSM_Odyss.Infrastructure.Exceptions;

namespace DSM_Odyss.Infrastructure.Repositories;

public sealed class ViajeRepository : RepositoryBase<Viaje>, IViajeRepository
{
    public ViajeRepository(ILogger<ViajeRepository>? logger = null)
        : base(logger)
    {
    }

    public ViajeRepository(ISession session, ILogger<ViajeRepository>? logger = null)
        : base(session, logger)
    {
    }

    public ViajeRepository(ISessionFactory sessionFactory, ILogger<ViajeRepository>? logger = null)
        : base(sessionFactory, logger)
    {
    }

    public async Task<IReadOnlyList<Viaje>> ReadAllAsync()
    {
        try
        {
            using var context = OpenSession();
            return await context.Session.Query<Viaje>().ToListAsync();
        }
        catch (Exception ex)
        {
            Logger?.LogError(ex, "Error reading all {Entity} entities.", EntityName);
            throw new DataException($"Error reading all {EntityName} entities.", ex);
        }
    }

    public async Task<Viaje?> ReadAsync(object id)
    {
        try
        {
            using var context = OpenSession();
            return await context.Session.GetAsync<Viaje>(id);
        }
        catch (Exception ex)
        {
            Logger?.LogError(ex, "Error reading {Entity} entity with id {EntityId}.", EntityName, id);
            throw new DataException($"Error reading {EntityName} entity.", ex);
        }
    }

    public async Task SaveAsync(Viaje entity)
    {
        await ExecuteRepositoryOperationInTransactionAsync(
            "Save",
            session => session.SaveOrUpdateAsync(entity),
            $"Error saving {EntityName} entity.");
    }

    public async Task DeleteAsync(Viaje entity)
    {
        await ExecuteRepositoryOperationInTransactionAsync(
            "Delete",
            session => session.DeleteAsync(entity),
            $"Error deleting {EntityName} entity.");
    }

    public async Task<IReadOnlyList<Viaje>> ViajesPublicosAsync()
    {
        try
        {
            using var context = OpenSession();
            return await context.Session.Query<Viaje>()
                .Where(entity => entity.EsPublico)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            Logger?.LogError(ex, "Error executing ReadFilter Viaje.viajesPublicos.");
            throw new DataException("Error executing ReadFilter Viaje.viajesPublicos.", ex);
        }
    }

    public async Task<IReadOnlyList<Viaje>> ViajesPorEstadoAsync(EstadoViaje p_estado)
    {
        try
        {
            using var context = OpenSession();
            return await context.Session.Query<Viaje>()
                .Where(entity => entity.Estado == p_estado)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            Logger?.LogError(ex, "Error executing ReadFilter Viaje.viajesPorEstado.");
            throw new DataException("Error executing ReadFilter Viaje.viajesPorEstado.", ex);
        }
    }
}